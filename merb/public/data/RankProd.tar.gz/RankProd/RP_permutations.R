
# PART 1
#
# This first part samples the null distribution by two methods: the first one
# takes lists as large as the original ones, permutes the ranks and calculates
# the RP. This is the same as permutation the original log ratios for two
# channel, one class problems.
# 
# The second method multiplies random values from 0 to 1, as many as samples.
# Without actually permuting any list of ranks
#
# Note that this version uses the RP score consisting in multiplying the
# relative ranks (the rank divided by the total number of genes).


# Sample lengths
l1 = 1000
l2 = 950
l3 = 800

# Common genes between samples
common= 700

# Number of permutations to compute
permutations.num = 100


# Classical way, permute the lists each time, select the common genes, and compute 
# RP scores for each of those genes.
permutations.full = vector()
for(i in 1:permutations.num){
  list1 = sample(seq(1,l1),common) / l1
  list2 = sample(seq(2,l2),common) / l2
  list3 = sample(seq(3,l3),common) / l3

  permutation = sapply(1:common,function(x){ list1[x] * list2[x] * list3[x]})
  permutations.full = cbind(permutations.full, permutation)
}


# Compute the permutations by multiplying random numbers
permutations.short = runif(permutations.num * common)
for (i in 2:3){
    permutations.short = permutations.short  * runif(permutations.num * common)
}



# Compare mean and variances for each of the classic permutations and the short
# version of the permutations
full.mean = apply(permutations.full,1, mean)
full.var = apply(permutations.full,1, var)
sum(full.var < var(permutations.short))
sum(full.mean < mean(permutations.short))

mean(full.mean)
mean(permutations.short)

mean(full.var)
var(permutations.short)

# Compare distribution of short permutation values with all the permutations
# values computed the classic way
qqplot(permutations.short, permutations.full); abline(0,1)


# Compare distribution of short permutation values with one of the permutations
# computed the classic way
qqplot(permutations.short, permutations.full[floor(runif(1,0,common)),]); abline(0,1)


# Kolmogorov-Smirnov test
ks.test(permutations.short , permutations.full)
ks.test(permutations.short , permutations.full[floor(runif(1,0,common)),])


ks.test(permutations.full[floor(runif(1,0,common)),], permutations.full[floor(runif(1,0,common)),])

##########################################################################

# Part 2
#
# This second part takes a one-class  dataset and uses a patched version
# of the RP function to show that the fast version of the permutations 
# gives the same results as the original version. This only works with
# one-class data!

library('RankProd')
source('R/RP.R')

# Lacking a better example we just use the class 1 samples in the Arabidopsis
# dataset.

data(arab)
arab.cl
data=arab[,arab.cl==1]
cl=arab.cl[arab.cl==1]

RP.out.normal = RP(data,cl,permutation.type='normal', num.perm=100)
RP.out.fast = RP(data,cl,permutation.type='fast',  num.perm= 50000)

# The p-values one version against the other. They are pretty much the same
plot(RP.out.normal$pval[[1]], RP.out.fast$pval[[1]]); abline(0,1)

# The p-values are not uniform, this is not just an artifact of the 
# dataset selection
plot(sort(RP.out.normal$pval[[1]]))

