

clean <- function(ratios){
  ratios[ratios == Inf] = NA
  ratios[!is.na(ratios)]
}

normalize <- function(ratios, max){
    return(data.frame(pos=seq(-1,1,length.out = length(ratios)), value = abs(sort(ratios))/max))
}

bin <- function(norm, bins){
  bin.num = factor(trunc(norm$pos * bins / 2))
  tapply(norm$value, bin.num, mean)
}


names = Sys.glob('data/*')

names = sample(names,100)

mids = vector()

bins = 500
bined.ratios = vector()

plot(c(),xlim=c(-1,1),ylim=c(0,1))
for (name in names){
    ratios = clean(scan(file=name, what=numeric(),quiet=T))
    if (length(ratios) == 0) next;

    mid = 1 - 2*sum(ratios < 0)/length(ratios)


    
    norm = normalize(ratios, max(abs(ratios),na.rm=T))
    mids = c(mids, mid)
    
    lines(value ~ pos, norm)
    abline( v = mid,col='red')
    bined.ratios = cbind(bined.ratios, bin(norm,bins))
}

average = data.frame(pos=seq(-1,1,length.out = dim(bined.ratios)[1]), value=apply(bined.ratios,1,mean))

lines(value ~ pos, average,col='blue',lwd=5)



train = average
train$ppos = abs(train$pos)

nls.fit = nls(value ~ A*B0*ppos + (1-A)*(exp(B1*ppos)/exp(B1)),train,start=c(A=0.7, B0 = 0.5, B1=40),trace=T)
print(nls.fit)

test = train
test$value = predict(nls.fit,test)


lines(value ~ pos, test,col='green',lwd=3)

plot(density(mids));
abline(v=0)